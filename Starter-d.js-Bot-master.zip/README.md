# Starter-Discord.js-Bot
A Simple Advanced Discord.js Starter Bot template with a good Handler with alliases and with a awesome help command!

## Get Started
Go to ``.env`` and paste your token there and run it by ``node index`` or ``npm start``
