const Discord = require('discord.js');
    module.exports = {
        info: {
            name: "botinfo",
            description: "This is an userinfo Command",
            usage: "",
            aliases: []
        },

        run: async function (client, message, args) { let userinfo = {};
        userinfo.bot = message.client.user.bot;
        userinfo.createdat = message.client.user.createdAt;
        userinfo.discrim = message.client.user.discriminator;
        userinfo.id = message.client.user.id;
        userinfo.mfa = message.client.user.mfaEnabled;
        userinfo.pre = message.client.user.premium;
        userinfo.presen = message.client.user.presence;
        userinfo.tag = message.client.user.tag;
        userinfo.uname = message.client.user.username;
        userinfo.verified = message.client.user.verified;
    
        userinfo.avatar = message.client.user.avatarURL;
            //Command execute starts from here
            const embed = new Discord.MessageEmbed()
            .setAuthor(userinfo.uname, userinfo.avatar)
        .addField("Bot?",userinfo.bot, true)
        .addField("Created At",userinfo.createdat, true)
        .addField("Discriminator",userinfo.discrim, true)
        .addField("Client ID",userinfo.id, true)
        .addField("2FA/MFA Enabled?",userinfo.mfa, true)
        .addField("Paid Account?",userinfo.pre, true)
        .addField("Presence",userinfo.presen, true)
        .addField("Client Tag",userinfo.tag, true)
        .addField("Username",userinfo.uname, true)
        .addField("Verified?",userinfo.verified, true)
        .setColor(0xf0e5da)
        .setFooter('!serverinfo')
        .setTitle("About this user...")
        .setThumbnail(userinfo.avatar)
            message.channel.send(embed)
        }
    }