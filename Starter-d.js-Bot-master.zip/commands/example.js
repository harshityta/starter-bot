const Discord = require('discord.js');
    module.exports = {
        info: {
            name: "example",
            description: "This is an Example Command",
            usage: "",
            aliases: []
        },

        run: async function (client, message, args) {
            //Command execute starts from here
            const embed = new Discord.MessageEmbed()
            .setTitle("RULES")
            .setDescription("Hello")
            message.channel.send(embed)
        }
    }


