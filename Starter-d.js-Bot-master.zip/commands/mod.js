module.exports = {
    info: {
        name: "mod",
        description: "This is an Example Command",
        usage: "",
        aliases: []
    },

    run: async function(client, message, args){
        //Command execute starts from here
        message.channel.send(" `!kick,!ban,!tempban` ")
    }
}
