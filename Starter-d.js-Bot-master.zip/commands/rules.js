const Discord = require('discord.js');
    module.exports = {
        info: {
            name: "rules",
            description: "This is an Rules Command",
            usage: "",
            aliases: []
        },

        run: async function (client, message, args) {
            //Command execute starts from here
            const embed = new Discord.MessageEmbed()
            .setColor('#0099ff')
	.setTitle('RULES')
	.setURL('https://tenor.com/view/idiot-lafuddyduddy-rules-follow-the-rules-penguin-gif-16685859')
	.setAuthor('FOLLOW THIS RULES', 'https://tenor.com/view/idiot-lafuddyduddy-rules-follow-the-rules-penguin-gif-16685859', 'https://tenor.com/view/idiot-lafuddyduddy-rules-follow-the-rules-penguin-gif-16685859')
	.setDescription('Some description here')
	.setThumbnail('https://tenor.com/view/idiot-lafuddyduddy-rules-follow-the-rules-penguin-gif-16685859')
	.addFields(
		{ name: 'Regular field title', value: 'Some value here' },
		{ name: '\u200B', value: '\u200B' },
		{ name: 'Inline field title', value: 'Some value here', inline: true },
		{ name: 'Inline field title', value: 'Some value here', inline: true },
	)
	.addField('Be Honest', 'Be Active', true)
	.setImage('https://tenor.com/view/idiot-lafuddyduddy-rules-follow-the-rules-penguin-gif-16685859')
	.setTimestamp()
	.setFooter('Read Rules', 'https://tenor.com/view/idiot-lafuddyduddy-rules-follow-the-rules-penguin-gif-16685859');

            message.channel.send(embed)
        }
    }
