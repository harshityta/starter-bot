module.exports = async (client) => {
  console.log(`[API] Logged in as ${client.user.username}`);
  await client.user.setActivity("Under Development", {
    type: "STREAMING",//can be LISTENING, WATCHING, PLAYING, STREAMING
    status: "dnd",//can be dnd, idle, online, invisible
  });
};
